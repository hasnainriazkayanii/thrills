<?php
 include('../Config/Connection.php');

  session_start();
  $login_check=$_SESSION['id'];
  $level = $_SESSION['level'] ?? 1;
  $status=$_SESSION['status']; 

header('Location: Purposetype.php');


        if (isset($_POST['submit'])) {
            
            $purpose=$_POST['purpose'];
         
           
             $delete= "TRUNCATE TABLE  purpose_type";
             $deleteres=mysqli_query($db, $delete);
      
            foreach($purpose as $key){
                
                 $query ="insert into `purpose_type`( purpose)values( '$key')";
                 
                $insert = mysqli_query($db, $query);
            }
            
            
        }
        
        
      
        
        ?>


<?php

 include('../Config/Connection.php');

 //Check Login

      session_start();

       $login_check=$_SESSION['id'];

     if ($login_check!='1')

     {
      $_SESSION['intended_url'] = $_SERVER['SCRIPT_URI'];
       header("../Login/login.php");

     }

     

    //End Login

    //Insert Customers

    if(isset($_POST['customer']))

    {

      $fname=$_POST['fname'];

      $lname=$_POST['lname'];

      $phone=$_POST['phone'];
      $country_code=$_POST['country_code'];
      $country_code_name = $_POST['add_customer_country_code'];
      

      // $mobnumber1  = str_replace("(", "", $mobnumber);

      //  $mobnumber2  = str_replace(")", "", $mobnumber1);

       

      //  $mobnumber3  = str_replace("-", "", $mobnumber2);

      //   $mobnumber4  = str_replace(" ", "", $mobnumber3);

     // var_dump($mobnumber4);die;

       //$lastvisit=$_POST['lastvisit'];

      $city=$_POST['city'];

      $ethnicity=$_POST['ethnicity'];

      $referral=$_POST['referral'];
      $friendname=$_POST['friend'];
    $purpose_type= $_POST['purpose_type'];
      $current_date=date("Y/m/d");

       $newDate = date("m/d/Y", strtotime($current_date));

      $customer_insert = "INSERT INTO customer(customer_id,first_name,Last_name,country_code,country_code_name,Phone_number,last_visit,homecity,ethnicity,referral,friend,purpose_type)VALUES ('0','$fname','$lname','$country_code','$country_code_name','$phone','$newDate','$city','$ethnicity','$referral','$friendname','$purpose_type')";
      
      $result = mysqli_query($db,$customer_insert);

       $id= mysqli_insert_id($db); 

      header( "Location: ../Orders/Addorders.php?id=$id" );

     /* header( "Location: CustomersDetails.php" );*/

    }

    //End Insert

    //Include Header

 include('../includes/header.php');

 //End Header

?>

      <div id="content-wrapper">

       <div class="container-fluid">

	  

	  <div class="col-md-12">

		<h3>Add Customer</h3>

	  <hr>

	   </div>	

	  <?php

    $ethnicityname = "SELECT * FROM ethnicity order by ethncity_name";
    $ethnicitsult = mysqli_query($db,$ethnicityname);

    //Referral Types
    $referral_sql = "SELECT * FROM referral_types where active = 0 order by name asc ";
    $referral_result = mysqli_query($db, $referral_sql);
    $referral_data = mysqli_fetch_all($referral_result, MYSQLI_ASSOC);

   ?>


	   <div class="container" style="display:flex;justify-content:center;margin-top:4%; ">

	   <div class="col-md-7">

	   

      <form action="AddCustomer.php" autocomplete='off' method="post" onblur="return validation();" name="vfrom">

        <div class="form-group">

    <label for="fname">First Name *</label>

    <input type="text" required class="form-control" onblur='setTimeout(()=>{$("#userlist").remove();}, 200)' onkeyup="checkUser(this,true);" name="fname" id="fname" aria-describedby="fname"  placeholder="First Name *" value="" >

    <span id="username"  class="text-danger font-weight-bold"> </span>

  </div>

  <div class="form-group">

    <label for="lname">Last Name *</label>
    <input type="hidden" name="country_code" id="country_code" value="">

    <input type="text" class="form-control" name="lname"id="lname" aria-describedby="lname" required placeholder="Last Name *" value="">

    <span id="lastname" class="text-danger font-weight-bold"> </span>

  </div>

   <div class="form-group">
    <label for="mobnumber">Mobile Number *</label>
    <br>
    <input type="tel" id="phone" required class="form-control" name="phone" aria-describedby="mobnumber" placeholder="Mobile Number *"  value="">
    <input type="hidden" id="add_customer_country_code" name="add_customer_country_code" value="">
  </div>

  

   <div class="form-group">

    <label for="Homecity">Home City *</label>

    

    <input type="text" class="form-control" name="city" id="city" aria-describedby="email" required placeholder="Home City *" value="">
    
<!-- INSERT NEW CODE -->
    
  <!--  
    <select name="city" class="form-control" id="city" aria-describedby="email">
      <option value="" selected>Select Customers Location</option>  
  <option value="AK">Alaska</option>
  <option value="AL">Alabama</option>
  <option value="AR">Arkansas</option>
  <option value="AZ">Arizona</option>
  <option value="CA">California (Northern)</option>
  <option value="CA">California (Southern)</option>
  <option value="CO">Colorado</option>
  <option value="CT">Connecticut</option>
  <option value="DC">DC</option>
  <option value="DE">Delaware</option>
  <option value="NFL">Florida (Northern)</option>
  <option value="CFL">Florida (Central FL)</option>
  <option value="SFL">Florida (South)</option>
  <option value="SWFL">Florida (Southwest)</option>
  <option value="GA">Georgia</option>
  <option value="HI">Hawaii</option>
  <option value="IA">Iowa</option>
  <option value="ID">Idaho</option>
  <option value="IL">Illinois</option>
  <option value="IN">Indiana</option>
  <option value="KS">Kansas</option>
  <option value="KY">Kentucky</option>
  <option value="LA">Louisiana</option>
  <option value="MA">Massachusetts</option>
  <option value="MD">Maryland</option>
  <option value="ME">Maine</option>
  <option value="MI">Michigan</option>
  <option value="MN">Minnesota</option>
  <option value="MO">Missouri</option>
  <option value="MS">Mississippi</option>
  <option value="MT">Montana</option>
  <option value="NC">North Carolina</option>
  <option value="ND">North Dakota</option>
  <option value="NE">New England</option>
  <option value="NH">New Hampshire</option>
  <option value="NJ">New Jersey</option>
  <option value="NM">New Mexico</option>
  <option value="NV">Nevada</option>
  <option value="NY">New York</option>
  <option value="OH">Ohio</option>
  <option value="OK">Oklahoma</option>
  <option value="OR">Oregon</option>
  <option value="Philly">Pennsylvania - Philly</option>
  <option value="Pitts">Pennsylvania - Pittsburgh</option>
  <option value="Erie">Pennsylvania - Erie</option>
  <option value="RI">Rhode Island</option>
  <option value="SC">South Carolina</option>
  <option value="SD">South Dakota</option>
  <option value="TN">Tennesee</option>
  <option value="Dallas">Texas - Dallas</option>
  <option value="Houston">Texas - Houston</option>
  <option value="San Antonio">Texas - San Antonio</option>
  <option value="UT">Utah</option>
  <option value="VA">Virginia</option>
  <option value="VT">Vermont</option>
  <option value="WA">Washington State</option>
  <option value="WI">Wisconsin</option>
  <option value="WV">West Virginia</option>
  <option value="WY">Wyoming</option>
  <option value="UKE">UNITED KINGDOM - ENGLAND</option>
  <option value="UKS">UNITED KINGDOM - SCOTLAND</option>
  <option value="IRELAND">IRELAND</option>
  <option value="GERMANY">GERMANY</option>
  <option value="USSR">RUSSIA</option>
  <option value="ARABIC">ARABIC COUNTRIES</option>
  <option value="NEUROPE">NORTHERN EUROPE</option>
  <option value="FRANCE">FRANCE</option>
  <option value="INDIA">INDIA</option>
  <option value="CHINA">CHINA</option>
  <option value="JAPAN">JAPAN</option>
  <option value="AUSTRALIA">AUSTRALIA</option>
  <option value="AFRICA">AFRICA</option>
  <option value="SOUTHAM">SOUTH AMERICA</option>

</select>
-->
    
    
    
    
    
    
    
<!-- END INSERT FUNCTION-->


    <span id="homecity" class="text-danger font-weight-bold"></span>

  </div> 

 <div class="form-group">

   <label for="fname">Ethnicity *</label> 

      <select required  class="form-control" name="ethnicity" id="ethnicity" >

         <option value="">Please Select Ethnicity..</option>

         <?php

       while($ethnicitsult1 = mysqli_fetch_assoc($ethnicitsult)) {

        $ethncity_name=$ethnicitsult1['ethncity_name'];



          ?>

     <option value="<?=$ethncity_name?>"><?=$ethncity_name?></option>

     <?php



   }?>

    </select>

</div>
   <div class="form-group">
    <label for="mobnumber">Purpose Of This Trip?*</label>
    <br>
    <?php 
    
    $sql = "SELECT * FROM purpose_type order by purpose asc";
$result = mysqli_query($db, $sql);
$datas =mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    ?>
    <select class="form-control" name="purpose_type">
        <option value="">Select Reason For Trip</option>
        <?php foreach($datas as $data ) { ?>
        <option value="<?php echo $data['purpose']?>"><?php echo $data['purpose']?> </option>
        
        
        
        <?php 
        
        
        
        }?>
        <option value="other">Other</option>
    </select>
    
  </div>

<?php if(count($referral_data) > 0):  //check for referral_data ?>
<!-- Referral types -->
 <div class="form-group">
   <label for="referral">Referred Through *</label> 
      <select required  class="form-control" name="referral" id="referral" onchange="referralInput(this);">
         <option value="">Please Select Referral..</option>

        <?php foreach($referral_data as $referral_option) {
        ?>
          <option value="<?=$referral_option['id']?>"> <?=$referral_option['name']?> </option>

        <?php } ?>

    </select>

</div>

<?php endif; //check for referral_data ?>


  <div class="form-group" style="text-align:center;">
    <button type="submit"  id="abcd"  onclick="myFunction()" name="customer"class="btn btn-primary">Submit</button>
  </div>

</form>



</div >

</div>

</div>

      </div>

      <!-- /.content-wrapper -->



    </div>

    <!-- /#wrapper -->



    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fas fa-angle-up"></i>

    </a>



    <!-- Logout Modal-->

    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

      <div class="modal-dialog" role="document">

        <div class="modal-content">

          <div class="modal-header">

            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>

            <button class="close" type="button" data-dismiss="modal" aria-label="Close">

              <span aria-hidden="true">×</span>

            </button>

          </div>

          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>

          <div class="modal-footer">

            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>

            <a class="btn btn-primary" href="login.html">Logout</a>

          </div>

        </div>

      </div>

    </div>





    <script type="text/javascript">

 $.validate({

    lang: 'en'

  });

 

</script>

<script>

    $("#TextBox1").on("keyup", function(e) {

  e.target.value = e.target.value.replace(/[^\d]/, "");

 e.target.value=e.target.value.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-');

  e.target.value=e.target.value.replace(/[^\w ]/,'');

 console.log(e.target.value.length);

  if (e.target.value.length === 10) {

    // do stuff

    var ph = e.target.value.split("");

    ph.splice(3, 0, ") "); ph.splice(7, 0, "-");

    $("#TextBox1").val('('+ph.join(""))

  }

})

</script>


<script src="../build/js/intlTelInput.js"></script>
  <script>
    var input = document.querySelector("#phone");
    window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
      // hiddenInput: "full_number",
      // initialCountry: "auto",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
      // separateDialCode: true,
      utilsScript: "../build/js/utils.js",
    });
  </script>
  <script>
    function myFunction(){
    var a=document.getElementsByClassName('iti__selected-flag')[0].title;
      const myArray = a.split(" ");
      var code=myArray[myArray.length - 1];
      document.getElementById('country_code').value =code;
   
 $('.iti__country-list').each(function(index,element){
        var b = $(element).find('.iti__active').attr('data-country-code');
        $('#add_customer_country_code').val(b);

      })




    }


  </script>

<script>
  function referralInput(el){
    if(el.value == '8'){
      let lable = "<label for='referral'>Friend Name</label>";
      let input = $("<input type='text' class='form-control' name='friend' placeholder='Friend Name' onblur='setTimeout(()=>{$(\"#userlist\").remove();},200)' onkeyup='checkUser(this);' required>");
      let input2 = $("<input id='userid' type='hidden' name='userid'>");
      let div = $('<div></div').attr('class','form-group').attr('id','friend').append(lable, input, input2);
      $(el).parent().after(div)
      
    }else{
      $('#friend').remove();
    }
  }
  
  
  function checkUser(elem, newuser=false){
    if(elem.value){
      ch = elem.value;
    }else{
      $('#userlist').remove();
      return false;
    }
    
    if(newuser){
      var userlink = 'UpdateCustomer.php?id=';
      var useraction = '';
    }else{
      var userlink = '#';
      var useraction = "onclick='setUser(this);'";
    }
    
    $.ajax({
      url: '../Customers/check_user.php?user=' + ch,
      success: function(response) {
        console.log(response);
        data = JSON.parse(response);
        let suggestions = $("<div></div>").addClass('dropdown').attr('id','userlist');
          let list = $("<div id='selectuser' class='dropdown-menu show bg-light'></div>");
          if(data.status == true){
            data.data.forEach(element => {
              listItem = $('<a onclick="setUser(this);" '+ useraction +'></a>').addClass('dropdown-item text-dark').attr('data-key', element.id).attr('href', userlink + element.id).html(element.name);
              list.append(listItem);
            });
            
          }

          suggestions.html(list);
          $('#userlist').remove();
          $(elem).after(suggestions);
        }

      });

  }

  function setUser(op){
    $('#userid').val($(op).data('key'));
    console.log($(op).data('key'));
    $('input[name=friend]').val($(op).text());
    $('#selectuser').hide();

  }

</script>


  </body>

</html>

